#include "FILA.h"
//#include "LISTA.h"
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <windows.h>
#include <unistd.h>

#define ANSI_RESET "\x1b[0m"
#define ANSI_BLACK "\x1b[30m"
#define ANSI_RED "\x1b[31m"
#define ANSI_GREEN "\x1b[32m"
#define ANSI_YELLOW "\x1b[33m"
#define ANSI_BLUE "\x1b[34m"
#define ANSI_MAGENTA "\x1b[35m"
#define ANSI_CYAN "\x1b[36m"
#define ANSI_WHITE "\x1b[37m"

struct Data
{
		int ano;
		int mes;
		int dia;
};

struct tarefa
{
		int codigo;
		int status;
		int prioridade;
		char nome_tarefa[30], nome_projeto[30];
		struct Data data_ini;
		struct Data data_fim;
};

void gotoxy(int x, int y)
{
		COORD coord;
		coord.X = x;
		coord.Y = y;
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

int menu(); //menu de escolhas
void add_tarefa(); //adicionar tarefa
void mod_tarefa(); //alterar tarefa
void marc_conc_tarefa(); //concluir tarefas
void status_tarefa(); //modificar status de tarefas
void pend_tarefas(); //tarefas pendentes
void imp_tarefas(); //tarefas concluídas sem atraso
void imp_tarefa_atrasada(); //tarefas concluídas com atraso

//ATRASADA - NÂO FOI FEITA E DIAHOJE > DIA DE TÉRMINO
//PENDENTE - NÃO FOI FEITA E DIADEHOJE < DIA DE TERMINO
//EM DIA - FEITA E DIADEHOJE < DIA DE TÉRMINO

void pula_linha(int n)
{
		for(int i=0; i<n; i++)
		{
				printf("\n");
		}
}

int main()
{
		setlocale(LC_ALL, "portuguese");

		int qntdtarefas = 0, saida=0;

		Fila *fila_pendentes = CriaFila();
		Fila *fila_concluidas = CriaFila();

		while(!saida)
		{
				system("cls");
				int esc = menu();

				switch (esc)
				{
						case 1:
								system("cls");
								printf(ANSI_YELLOW "-----ADICIONANDO UMA NOVA TAREFA-----\n\n" ANSI_RESET);
								add_tarefa(fila_pendentes, &qntdtarefas);
								break;
						case 2:
								system("cls");
								printf(ANSI_YELLOW "-----ALTERANDO UMA TAREFA-----\n\n" ANSI_RESET);
								mod_tarefa(fila_pendentes);
								break;
						case 3:
								system("cls");
								printf(ANSI_YELLOW "-----MARCANDO UMA TAREFA COMO CONCLUÍDA-----\n\n" ANSI_RESET);
								marc_conc_tarefa(fila_pendentes, fila_concluidas);
								break;
						case 4:
								system("cls");
								printf(ANSI_YELLOW "-----STATUS DE TAREFAS-----\n\n"ANSI_RESET);
								status_tarefa(fila_pendentes);
								break;
						case 5:
								system("cls");
								printf(ANSI_YELLOW "-----LISTA DE TAREFAS PENDENTES-----\n" ANSI_RESET);
								pend_tarefas(fila_pendentes);
								break;
						case 6:
								system("cls");
								printf(ANSI_YELLOW "-----LISTA DE TAREFAS CONCLUÍDAS-----\n\n" ANSI_RESET);
								imp_tarefas(fila_concluidas);
								break;
						case 7:
								system("cls");
								printf(ANSI_MAGENTA "SAINDO DO PROGRAMA" ANSI_RESET);
								for (int i=0; i<3; i++)
								{
										printf(ANSI_MAGENTA "." ANSI_RESET);
										sleep(1);
								}
								liberaFila(fila_pendentes);
								liberaFila(fila_concluidas);
								saida=1;
								break;
						default:
								system("cls");
								printf(ANSI_MAGENTA "OPÇÃO INVÁLIDA!" ANSI_RESET);
								for (int i=0; i<3; i++)
								{
										printf(ANSI_MAGENTA "." ANSI_RESET);
										sleep(1);
								}
				}
		}
		return 0;
}

int menu()
{
		int esc;
		printf(ANSI_CYAN "------MENU DO GERENCIADOR DE TAREFAS------" ANSI_RESET);
		printf("\n[1] Adicionar uma nova tarefa");
		printf("\n[2] Alterar uma tarefa");
		printf("\n[3] Marcar uma tarefa como concluída");
		printf("\n[4] Verificar se há tarefas atrasadas");
		printf("\n\n[5] Lista das tarefas pendentes");
		printf("\n[6] Lista das tarefas concluídas");
		printf("\n[7] Sair");
		printf("\n>> ");
		gotoxy(3,9);
		scanf("%d", &esc);

		return esc;
}

int tamanho(int numero)
{
		int cont = 0;

		while (numero != 0)
		{
				numero/=10;
				cont++;
		}

		return cont;
}

void add_tarefa(Fila *fila_pendentes, int *qntdtarefas)
{
		struct tarefa *Tarefasnovas = (struct tarefa*) malloc(sizeof(struct tarefa));

		printf("Insira o código da tarefa: ");
		printf("\n>> ");
		scanf("%d", &Tarefasnovas->codigo);

		printf("\nInsira o nome da tarefa: ");
		printf("\n>> ");
		scanf("%s", &Tarefasnovas->nome_tarefa);

		printf("\nInsira o nome do projeto: ");
		printf("\n>> ");
		scanf("%s", &Tarefasnovas->nome_projeto);

		printf("\nInsira a data de início da tarefa (formato: DD/MM/AAAA)");
		printf("\n>> ");
		scanf("%d/%d/%d", &Tarefasnovas->data_ini.dia, &Tarefasnovas->data_ini.mes, &Tarefasnovas->data_ini.ano);

		printf("\nInsira a data de término da tarefa (formato: DD/MM/AAAA)");
		printf("\n>> ");
		scanf("%d/%d/%d", &Tarefasnovas->data_fim.dia, &Tarefasnovas->data_fim.mes, &Tarefasnovas->data_fim.ano);

		do
		{
				printf("\nInsira a prioridade da tarefa");
				printf("\n[1] Alta prioridade");
				printf("\n[2] Prioridade normal");
				printf("\n[3] Baixa prioridade");
				printf("\n>> ");
				scanf("%d", &Tarefasnovas->prioridade);
		}
		while (Tarefasnovas->prioridade<1 || Tarefasnovas->prioridade>3);

		Tarefasnovas->status = -1;
		InsereFila(fila_pendentes, Tarefasnovas);
		printf(ANSI_GREEN "\nTAREFA ADICIONADA COM ÊXITO!\n" ANSI_RESET);

		(*qntdtarefas)++;

		sleep(3);
}

void mod_tarefa(Fila *fila_pendentes)
{
		int codigo, existe = 0;
		Fila *fila_temp = CriaFila();
		int opcalt;

		printf("Insira o código da tarefa que deseja alterar");
		printf("\n>> ");
		scanf("%d", &codigo);

		while (!VaziaFila(fila_pendentes))
		{
				struct tarefa *tarefa = RetiraFila(fila_pendentes);

				if (tarefa->codigo == codigo)
				{
						existe = 1;
						do
						{
								printf("\nEscolha a informação que deseja alterar\n");
								printf("[1] Código da tarefa\n");
								printf("[2] Nome da tarefa\n");
								printf("[3] Nome do projeto\n");
								printf("[4] Data de início\n");
								printf("[5] Data de término\n");
								printf("[6] Prioridade");
								printf("\n>> ");
								scanf("%d", &opcalt);

								if (opcalt<1 || opcalt>6)
								{
										printf(ANSI_RED "OPÇÃO INVÁLIDA" ANSI_RESET);
										sleep(3);
								}
						}
						while(opcalt<1 || opcalt>6);


						switch (opcalt)
						{
						case 1:
								printf("\nInsira o novo código da tarefa %d", tarefa->codigo);
								printf("\n>> ");
								scanf("%d", &tarefa->codigo);
								printf(ANSI_GREEN "\nCÓDIGO DA TAREFA ALTERADO COM ÊXITO!" ANSI_RESET);
								sleep(3);
								break;
						case 2:
								printf("\nInsira o novo nome da tarefa %d", tarefa->codigo);
								printf("\n>> ");
								scanf("%s", &tarefa->nome_tarefa);
								printf(ANSI_GREEN "\nNOME DA TAREFA ALTERADO COM ÊXITO!" ANSI_RESET);
								sleep(3);
								break;
						case 3:
								printf("\nInsira o novo nome do projeto da tarefa %d", tarefa->codigo);
								printf("\n>> ");
								scanf("%s", &tarefa->nome_projeto);
								printf(ANSI_GREEN "\nNOME DO PROJETO ALTERADO COM ÊXITO!" ANSI_RESET);
								sleep(3);
								break;
						case 4:
								do
								{
										printf("\nInsira a nova data de início da tarefa (formato: DD/MM/AAAA)");
										printf("\n>> ");
										scanf("%d/%d/%d", &tarefa->data_ini.dia, &tarefa->data_ini.mes, &tarefa->data_ini.ano);

										if(tarefa->data_ini.dia>31 || tarefa->data_ini.mes>12 || tarefa->data_ini.ano>9999)
										{
											 printf(ANSI_RED "DATA INVÁLIDA" ANSI_RESET);
										}
								}while (tarefa->data_ini.dia>31 || tarefa->data_ini.mes>12 || tarefa->data_ini.ano>9999);

								printf(ANSI_GREEN "\nDATA DE INÍCIO DA TAREFA ALTERADO COM ÊXITO!" ANSI_RESET);
								sleep(3);
								break;
						case 5:
								do
								{
										printf("\nInsira a nova data de término da tarefa (formato: DD/MM/AAAA)");
										printf("\n>> ");
										scanf("%d/%d/%d", &tarefa->data_fim.dia, &tarefa->data_fim.mes, &tarefa->data_fim.ano);

										if(tarefa->data_fim.dia>31 || tarefa->data_fim.mes>12 || tarefa->data_fim.ano>9999)
										{
											 printf(ANSI_RED "DATA INVÁLIDA" ANSI_RESET);
										}
								}while (tarefa->data_fim.dia>31 || tarefa->data_fim.mes>12 || tarefa->data_fim.ano>9999);

								printf(ANSI_GREEN "\nDATA DE TÉRMINO DA TAREFA ALTERADO COM ÊXITO!" ANSI_RESET);
								sleep(3);
								break;
						case 6:
								do
								{
										printf("\nInsira a prioridade da tarefa");
										printf("\n[1] Alta prioridade");
										printf("\n[2] Prioridade normal");
										printf("\n[3] Baixa prioridade");
										printf("\n>> ");
										scanf("%d", &tarefa->prioridade);

										if (tarefa->prioridade<1 || tarefa->prioridade>3)
										{
												printf(ANSI_RED "OPÇÃO INVÁLIDA" ANSI_RESET);
												sleep(3);
										}
								}
								while (tarefa->prioridade<1 || tarefa->prioridade>3);
								printf(ANSI_GREEN "\nPRIORIDADE DA TAREFA ALTERADO COM ÊXITO!" ANSI_RESET);
								sleep(3);
								break;
						default:
								printf(ANSI_RED "OPÇÃO INVÁLIDA!" ANSI_RESET);
								sleep(3);
						}
				}

				InsereFila(fila_temp, tarefa);
		}

		while (!VaziaFila(fila_temp))
		{
				struct tarefa *tarefa = RetiraFila(fila_temp);
				InsereFila(fila_pendentes, tarefa);
		}

		liberaFila(fila_temp);

		 if (!existe)
		{
				printf(ANSI_RED "\nTAREFA DE CÓDIGO %d NÃO EXISTE!\n" ANSI_RESET, codigo);
				sleep(3);
		}
}

void status_tarefa(Fila *fila_pendentes)
{
		time_t hoje;
		time(&hoje);
		struct tm data_atual;
		data_atual = *localtime(&hoje);
		int atraso = 0;

		printf("Hoje é %d/%d/%d\n", data_atual.tm_mday, data_atual.tm_mon + 1, data_atual.tm_year + 1900);
		int dia_hoje = data_atual.tm_mday;
		int mes_hoje = data_atual.tm_mon + 1;
		int ano_hoje = data_atual.tm_year + 1900;

		Fila *fila_temp = CriaFila();
		struct tarefa *tarefa;

		while (!VaziaFila(fila_pendentes))
		{
				tarefa = RetiraFila(fila_pendentes);

				if (ano_hoje>=tarefa->data_fim.ano && mes_hoje>=tarefa->data_fim.mes && dia_hoje>tarefa->data_fim.dia)
				{
						tarefa->status = 1;
						printf(ANSI_YELLOW "\n%s ESTÁ ATRASADA!\n" ANSI_RESET, tarefa->nome_tarefa);
						atraso = 1;
						sleep(3);
				}
				else
				{
						tarefa->status = 0;
				}

				InsereFila(fila_temp, tarefa);
		}

		if (!atraso)
		{
				printf(ANSI_GREEN "NENHUMA TAREFA ESTÁ ATRASADA, PARABÉNS!" ANSI_RESET); //coloridoooo
				sleep(3);
		}

		while (!VaziaFila(fila_temp))
		{
				struct tarefa *tarefa = RetiraFila(fila_temp);
				InsereFila(fila_pendentes, tarefa);
		}

		liberaFila(fila_temp);
}

void marc_conc_tarefa(Fila *fila_pendentes, Fila *fila_concluidas)
{
		int codigo;
		int enc_tarefa = 0;

		Fila *fila_temp = CriaFila();

		printf("Insira o código da tarefa que deseja marcar como concluída: ");
		printf("\n>> ");
		scanf("%d", &codigo);

		while (!VaziaFila(fila_pendentes))
		{
				struct tarefa *tarefa = RetiraFila(fila_pendentes);

				if (tarefa->codigo == codigo)
				{
						enc_tarefa = 1;

						if (tarefa->status == 0)
						{
								printf(ANSI_YELLOW "TAREFA '%s' JÁ ESTÁ CONCLUÍDA!" ANSI_RESET, tarefa->nome_tarefa);
								sleep(1);
						}
						else if (tarefa->status == -1)
						{
								tarefa->status = 0;
								InsereFila(fila_concluidas, tarefa);
								printf(ANSI_GREEN "TAREFA '%s' FOI MARCADA COMO CONCLUÍDA COM ÊXITO!" ANSI_RESET, tarefa->nome_tarefa);
								sleep(1);
						}
				}else
				{
						InsereFila(fila_temp, tarefa);
				}
		}

		while (!VaziaFila(fila_temp))
		{
				struct tarefa *tarefa = RetiraFila(fila_temp);
				InsereFila(fila_pendentes, tarefa);
		}

		liberaFila(fila_temp);

		if (!enc_tarefa)
		{
				printf(ANSI_RED "TAREFA COM CÓDIGO %d NÃO EXISTE!" ANSI_RESET, codigo);
				sleep(3);
		}
}

void pend_tarefas(Fila *fila_pendentes)
{
		if (VaziaFila(fila_pendentes))
		{
				printf(ANSI_RED "\nNÃO HÁ TAREFAS PENDENTES!" ANSI_RESET);
		}
		else
		{
				Fila *fila_temp = CriaFila();
				int qntdtarefas = 1;

				while (!VaziaFila(fila_pendentes))
				{
						struct tarefa *tarefas = RetiraFila(fila_pendentes);
						printf(ANSI_CYAN "\nTAREFA %d\n" ANSI_RESET, qntdtarefas);
						printf("Código da tarefa: %d\n", tarefas->codigo);
						printf("Nome da tarefa: %s\n", tarefas->nome_tarefa);
						printf("Nome do projeto: %s\n", tarefas->nome_projeto);
						printf("Data de início: %02d/%02d/%d\n", tarefas->data_ini.dia, tarefas->data_ini.mes, tarefas->data_ini.ano);
						printf("Data de término: %02d/%02d/%d\n", tarefas->data_fim.dia, tarefas->data_fim.mes, tarefas->data_fim.ano);
						printf("Prioridade da tarefa: %d\n", tarefas->prioridade);
						qntdtarefas++;

						InsereFila(fila_temp, tarefas);
				}

				while (!VaziaFila(fila_temp))
				{
						struct tarefa *tarefas = RetiraFila(fila_temp);
						InsereFila(fila_pendentes, tarefas);
				}

				liberaFila(fila_temp);
		}

		printf("\n\nPressione qualquer tecla para continuar");
		do
		{
				for (int i = 0; i < 3; i++)
				{
						printf(".");
						sleep(1);
				}
				printf("\b\b\b   \b\b\b");
		} while (!kbhit());
}

void imp_tarefas(Fila *fila_concluidas)
{
		if (VaziaFila(fila_concluidas))
		{
				printf(ANSI_RED "NÃO HÁ TAREFAS CONCLUÍDAS!" ANSI_RESET);
		}
		else
		{
				Fila *fila_temp = CriaFila();
				int qntdtarefas = 1;

				while (!VaziaFila(fila_concluidas))
				{
						struct tarefa *tarefa = RetiraFila(fila_concluidas);
						printf(ANSI_CYAN "TAREFA %d\n" ANSI_RESET, qntdtarefas);
						printf("Código da tarefa: %d\n", tarefa->codigo);
						printf("Nome da tarefa: %s\n", tarefa->nome_tarefa);
						printf("Nome do projeto: %s\n", tarefa->nome_projeto);
						printf("Data de início: %02d/%02d/%d\n", tarefa->data_ini.dia, tarefa->data_ini.mes, tarefa->data_ini.ano);
						printf("Data de término: %02d/%02d/%d\n", tarefa->data_fim.dia, tarefa->data_fim.mes, tarefa->data_fim.ano);
						printf("Prioridade da tarefa: %d\n", tarefa->prioridade);
						qntdtarefas++;

						InsereFila(fila_temp, tarefa);
				}

				while (!VaziaFila(fila_temp))
				{
						struct tarefa *tarefa = RetiraFila(fila_temp);
						InsereFila(fila_concluidas, tarefa);
				}

				liberaFila(fila_temp);
		}

		printf("\n\nPressione qualquer tecla para continuar");
		do
		{
				for (int i = 0; i < 3; i++)
				{
						printf(".");
						sleep(1);
				}
				printf("\b\b\b   \b\b\b");
		} while (!kbhit());
}

