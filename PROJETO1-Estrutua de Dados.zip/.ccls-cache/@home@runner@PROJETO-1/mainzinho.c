#include "FILA.h"
#include <stdio.h>
#include <stdlib.h>
//#include <windows.h>

typedef struct data {
  int ano;
  short mes;
  short dia;
} data;

typedef struct tarefa {
  int codigo, status; // 1 (atrasada)/ 0 (em dia) / -1 (pendente)
  data *data_ini, *data_fim;
  char nome_tarefa[30], nome_projeto[30];
} tarefa;

void limpatela() {
  system("cls");
  // return 0;
}

int menu();
void add_tarefa();
void mod_tarefa();
void marc_conc_tarefa();
void status_tarefa();
void pend_tarefas();
void conc_tarefas();
void imp_tarefa1(); // tarefa sem atraso
void imp_tarefa2(); // tarefa com atraso

int main() {
  int esc = menu();

  switch (esc)
	{
	  case 1:
	    limpatela;
	  	// opçao 1;
	  	break;
		case 2:
		  limpatela;
		  // opçao 2;
		  break;
		case 3:
		  limpatela;
		  // opçao 3;
		  break;
		case 4:
		  limpatela;
		  // opçao 4;
		  break;
		case 5:
		  limpatela;
		  // opçao 5;
		  break;
		case 6:
		  limpatela;
		  printf("Escolha qual lista deseja ver");
		  printf("\n[1] Lista de tarefas concluídas COM atraso");
		  printf("\n[2] Lista de tarefas concluídas SEM atraso");
		  break;
		default:
		  printf("OPÇÃO INVÁLIDA SEU MULEKINHO DE BOSTA");
	}

  return 0;
}

int menu() {
  int esc;

  printf("--------------------MENU--------------------");
  printf("\n[1] Adicionar uma nova tarefa");
  printf("\n[2] Alterar uma tarefa");
  printf("\n[3] Marcar uma tarefa como concluída");
  printf("\n[4] Status de uma tarefa");
  printf("\n\n[5] Lista das tarefas pendentes");
  printf("\n[6] Lista das tarefas concluídas");
  printf("\n>> ");
  scanf("%d", &esc);

  return esc;
}
